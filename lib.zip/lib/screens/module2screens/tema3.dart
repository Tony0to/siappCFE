import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:siapp/screens/module2screens/tema4.dart';
import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter_highlighter/flutter_highlighter.dart';
import 'package:flutter_highlighter/themes/github.dart';
import 'package:siapp/theme/app_colors.dart'; // Import AppColors

class Tema3 extends StatefulWidget {
  final Map<String, dynamic> section;
  final String sectionTitle;
  final int sectionIndex;
  final int totalSections;
  final Map<String, dynamic> content;
  final Map<String, dynamic> moduleData;
  final Function(int) onComplete;

  const Tema3({
    Key? key,
    required this.section,
    required this.sectionTitle,
    required this.sectionIndex,
    required this.totalSections,
    required this.content,
    required this.moduleData,
    required this.onComplete,
  }) : super(key: key);

  @override
  _Tema3State createState() => _Tema3State();
}

class _Tema3State extends State<Tema3> with TickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  Map<String, dynamic>? _contentData;
  Map<int, dynamic> _userAnswers = {};
  Map<int, bool> _showResults = {};

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _fadeAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.1),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic));
    _loadContentData();
    _controller.forward();
  }

  Future<void> _loadContentData() async {
    try {
      final String jsonString = await rootBundle.loadString('assets/data/module2/tema3.json');
      final jsonData = json.decode(jsonString);
      setState(() {
        _contentData = jsonData;
      });
    } catch (e) {
      debugPrint('Error loading JSON: $e');
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Widget _buildSectionImage() {
    const imageUrl = 'https://img.freepik.com/free-vector/programming-concept-illustration_114360-1351.jpg';
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: Stack(
        children: [
          CachedNetworkImage(
            imageUrl: imageUrl,
            height: 180,
            width: double.infinity,
            fit: BoxFit.cover,
            placeholder: (context, url) => Container(
              color: AppColors.glassmorphicBackground,
              child: const Center(child: CircularProgressIndicator()),
            ),
            errorWidget: (context, url, error) => Container(
              color: AppColors.glassmorphicBackground,
              child: const Icon(Icons.image_not_supported, size: 50),
            ),
          ),
          Container(
            height: 180,
            decoration: BoxDecoration(
              gradient: AppColors.headerSection,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHighlightBox(String content, {Color? color, String? title}) {
    return Container(
      padding: const EdgeInsets.all(16),
      margin: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(
        color: color ?? AppColors.glassmorphicBackground,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppColors.glassmorphicBorder,
          width: 1.5,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (title != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Text(
                title,
                style: GoogleFonts.poppins(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: color ?? AppColors.codeBoxLabel,
                ),
              ),
            ),
          Text(
            content,
            style: GoogleFonts.poppins(
              fontSize: 15,
              color: AppColors.textSecondary,
              fontStyle: title != null ? FontStyle.italic : null,
              height: 1.6,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCodeBox(String code, String language) {
    String highlightLanguage;
    switch (language.toLowerCase()) {
      case 'javascript':
        highlightLanguage = 'javascript';
        break;
      case 'python':
        highlightLanguage = 'python';
        break;
      case 'java':
        highlightLanguage = 'java';
        break;
      case 'c++':
        highlightLanguage = 'cpp';
        break;
      case 'ejemplo genérico':
        highlightLanguage = 'text';
        break;
      default:
        highlightLanguage = 'text';
    }

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.codeBoxBackground,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.codeBoxBorder),
        boxShadow: [
          BoxShadow(
            color: AppColors.shadowColor,
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: AppColors.codeBoxLabel,
              borderRadius: BorderRadius.circular(24),
            ),
            child: Text(
              'Ejemplo de Código',
              style: GoogleFonts.poppins(
                fontSize: 15,
                fontWeight: FontWeight.w600,
                color: AppColors.textPrimary,
              ),
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.textPrimary,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: AppColors.shadowColor,
                  blurRadius: 4,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: SingleChildScrollView(
                scrollDirection: Axis.vertical,
                child: HighlightView(
                  code,
                  language: highlightLanguage,
                  theme: githubTheme,
                  padding: const EdgeInsets.all(12),
                  textStyle: GoogleFonts.sourceCodePro(
                    fontSize: 14,
                    height: 1.4,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBulletList(List<dynamic> items) {
    return Column(
      children: items.map((item) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(Icons.fiber_manual_record, size: 10, color: AppColors.textSecondary),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                item.toString(),
                style: GoogleFonts.poppins(
                  fontSize: 15,
                  color: AppColors.textSecondary,
                  height: 1.5,
                ),
              ),
            ),
          ],
        ),
      )).toList(),
    );
  }

  List<Widget> _formatContent(String content) {
    return content.split('\n').map((paragraph) {
      if (paragraph.trim().isEmpty) return const SizedBox(height: 12);
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Text(
          paragraph,
          style: GoogleFonts.poppins(
            fontSize: 15,
            color: AppColors.textPrimary,
            height: 1.6,
          ),
        ),
      );
    }).toList();
  }

  Widget _buildQuizSection() {
    if (_contentData?['quiz'] == null) return const SizedBox.shrink();

    final quiz = _contentData!['quiz'];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          quiz['titulo'],
          style: GoogleFonts.poppins(
            fontSize: 22,
            fontWeight: FontWeight.w600,
            color: AppColors.textPrimary,
          ),
        ),
        const SizedBox(height: 12),
        Text(
          quiz['descripcion'],
          style: GoogleFonts.poppins(
            fontSize: 15,
            color: AppColors.textSecondary,
            height: 1.6,
          ),
        ),
        const SizedBox(height: 16),
        ...quiz['preguntas'].asMap().entries.map<Widget>((entry) {
          final index = entry.key;
          final pregunta = entry.value;
          return Card(
            elevation: 4,
            margin: const EdgeInsets.only(bottom: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            color: AppColors.cardBackground,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Pregunta ${index + 1}: ${pregunta['pregunta']}',
                    style: GoogleFonts.poppins(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 12),
                  if (pregunta['tipo'] == 'multiple_choice')
                    ...pregunta['opciones'].asMap().map((i, opcion) {
                      return MapEntry(
                        i,
                        RadioListTile<String>(
                          title: Text(
                            opcion,
                            style: GoogleFonts.poppins(
                              fontSize: 15,
                              color: AppColors.textSecondary,
                            ),
                          ),
                          value: opcion,
                          groupValue: _userAnswers[index],
                          activeColor: AppColors.success,
                          onChanged: (value) {
                            setState(() {
                              _userAnswers[index] = value;
                            });
                          },
                        ),
                      );
                    }).values.toList()
                  else if (pregunta['tipo'] == 'true_false')
                    Column(
                      children: [
                        RadioListTile<bool>(
                          title: Text(
                            'Verdadero',
                            style: GoogleFonts.poppins(
                              fontSize: 15,
                              color: AppColors.textSecondary,
                            ),
                          ),
                          value: true,
                          groupValue: _userAnswers[index],
                          activeColor: AppColors.success,
                          onChanged: (value) {
                            setState(() {
                              _userAnswers[index] = value;
                            });
                          },
                        ),
                        RadioListTile<bool>(
                          title: Text(
                            'Falso',
                            style: GoogleFonts.poppins(
                              fontSize: 15,
                              color: AppColors.textSecondary,
                            ),
                          ),
                          value: false,
                          groupValue: _userAnswers[index],
                          activeColor: AppColors.success,
                          onChanged: (value) {
                            setState(() {
                              _userAnswers[index] = value;
                            });
                          },
                        ),
                      ],
                    ),
                  const SizedBox(height: 12),
                  ElevatedButton(
                    onPressed: _userAnswers[index] == null
                        ? null
                        : () {
                            setState(() {
                              _showResults[index] = true;
                            });
                          },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primaryButton,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    child: Text(
                      'Verificar',
                      style: GoogleFonts.poppins(
                        fontSize: 14,
                        color: AppColors.buttonText,
                      ),
                    ),
                  ),
                  if (_showResults[index] == true) ...[
                    const SizedBox(height: 12),
                    Text(
                      _userAnswers[index] == pregunta['respuesta_correcta']
                          ? '¡Correcto!'
                          : 'Incorrecto',
                      style: GoogleFonts.poppins(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: _userAnswers[index] == pregunta['respuesta_correcta']
                            ? AppColors.success
                            : AppColors.error,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Explicación: ${pregunta['explicacion']}',
                      style: GoogleFonts.poppins(
                        fontSize: 15,
                        color: AppColors.textSecondary,
                        fontStyle: FontStyle.italic,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          );
        }).toList(),
        const SizedBox(height: 80),
      ],
    );
  }

  void _navigateNext() {
    widget.onComplete(widget.sectionIndex);
    final nextIndex = widget.sectionIndex + 1;
    final nextSectionKey = widget.content.keys.elementAt(nextIndex);
    final nextSection = widget.content[nextSectionKey];
    Navigator.pushReplacement(
      context,
      PageRouteBuilder(
        pageBuilder: (context, animation, secondaryAnimation) => Tema4(
          section: nextSection,
          sectionTitle: nextSection['title'] ?? 'Sección ${nextIndex + 1}',
          sectionIndex: nextIndex,
          totalSections: widget.totalSections,
          content: widget.content,
          moduleData: widget.moduleData,
          onComplete: widget.onComplete,
        ),
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          return FadeTransition(opacity: animation, child: child);
        },
        transitionDuration: const Duration(milliseconds: 300),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_contentData == null) {
      return Scaffold(
        backgroundColor: AppColors.backgroundDark,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(AppColors.progressActive),
              ),
              const SizedBox(height: 20),
              Text(
                'Cargando contenido...',
                style: GoogleFonts.poppins(
                  fontSize: 16,
                  color: AppColors.textPrimary,
                ),
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: Text(
          widget.sectionTitle,
          style: GoogleFonts.poppins(
            fontSize: 20,
            fontWeight: FontWeight.w600,
            color: AppColors.textPrimary,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: AppColors.textPrimary),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _navigateNext,
        backgroundColor: AppColors.primaryButton,
        foregroundColor: AppColors.buttonText,
        icon: const Icon(Icons.arrow_forward),
        label: Text(
          'Siguiente',
          style: GoogleFonts.poppins(fontWeight: FontWeight.w600),
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: AppColors.backgroundDynamic,
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                FadeTransition(
                  opacity: _fadeAnimation,
                  child: SlideTransition(
                    position: _slideAnimation,
                    child: _buildSectionImage(),
                  ),
                ),
                const SizedBox(height: 20),

                // Introducción
                if (_contentData?['introduccion'] != null)
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ..._formatContent(_contentData!['introduccion']['contenido']),
                      const SizedBox(height: 16),
                      _buildHighlightBox(
                        _contentData!['introduccion']['highlight']['text'],
                        color: AppColors.successGradient.colors.first.withOpacity(0.2),
                        title: "Importante",
                      ),
                      const SizedBox(height: 24),
                    ],
                  ),

                // Características
                if (_contentData?['caracteristicas'] != null)
                  Card(
                    elevation: 4,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    color: AppColors.cardBackground,
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _contentData!['caracteristicas']['titulo'],
                            style: GoogleFonts.poppins(
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                              color: AppColors.textPrimary,
                            ),
                          ),
                          const SizedBox(height: 12),
                          _buildBulletList(_contentData!['caracteristicas']['items']),
                        ],
                      ),
                    ),
                  ),

                const SizedBox(height: 24),

                // Subtema 1: Secuenciales
                if (_contentData?['subtema1'] != null)
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _contentData!['subtema1']['titulo'],
                        style: GoogleFonts.poppins(
                          fontSize: 22,
                          fontWeight: FontWeight.w600,
                          color: AppColors.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 12),
                      ..._formatContent(_contentData!['subtema1']['contenido']),
                      const SizedBox(height: 16),

                      // Ejemplo de código
                      Card(
                        elevation: 4,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        color: AppColors.cardBackground,
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                _contentData!['subtema1']['ejemplo']['titulo'],
                                style: GoogleFonts.poppins(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                  color: AppColors.textPrimary,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                _contentData!['subtema1']['ejemplo']['descripcion'],
                                style: GoogleFonts.poppins(
                                  fontSize: 15,
                                  color: AppColors.textSecondary,
                                ),
                              ),
                              const SizedBox(height: 12),
                              _buildCodeBox(
                                _contentData!['subtema1']['ejemplo']['codigo'],
                                "JavaScript",
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      Text(
                        _contentData!['subtema1']['conclusion'],
                        style: GoogleFonts.poppins(
                          fontSize: 15,
                          color: AppColors.textSecondary,
                        ),
                      ),
                      const SizedBox(height: 24),
                    ],
                  ),

                // Subtema 2: Condicionales
                if (_contentData?['subtema2'] != null)
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _contentData!['subtema2']['titulo'],
                        style: GoogleFonts.poppins(
                          fontSize: 22,
                          fontWeight: FontWeight.w600,
                          color: AppColors.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 12),
                      ..._formatContent(_contentData!['subtema2']['contenido']),
                      const SizedBox(height: 16),

                      // Lista de condicionales
                      ..._contentData!['subtema2']['condicionales'].map<Widget>((condicional) {
                        Color color;
                        switch (condicional['color']) {
                          case 'blue':
                            color = AppColors.progressBrightBlue;
                            break;
                          case 'purple':
                            color = Colors.purple;
                            break;
                          case 'indigo':
                            color = Colors.indigo;
                            break;
                          case 'teal':
                            color = Colors.teal;
                            break;
                          case 'cyan':
                            color = AppColors.accentAqua;
                            break;
                          default:
                            color = AppColors.progressBrightBlue;
                        }

                        return Card(
                          elevation: 4,
                          margin: const EdgeInsets.only(bottom: 16),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          color: color.withOpacity(0.2),
                          child: Padding(
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Condicional ${condicional['tipo']}",
                                  style: GoogleFonts.poppins(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w600,
                                    color: AppColors.textPrimary,
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  condicional['descripcion'],
                                  style: GoogleFonts.poppins(
                                    fontSize: 15,
                                    color: AppColors.textSecondary,
                                  ),
                                ),
                                const SizedBox(height: 12),
                                _buildCodeBox(
                                  condicional['ejemplo'],
                                  condicional['tipo'] == 'switch' || condicional['tipo'] == 'switch sin break'
                                      ? "JavaScript"
                                      : "Ejemplo genérico",
                                ),
                              ],
                            ),
                          ),
                        );
                      }).toList(),

                      // Nota importante
                      _buildHighlightBox(
                        _contentData!['subtema2']['nota_importante']['text'],
                        color: AppColors.successGradient.colors.first.withOpacity(0.2),
                        title: "Importante",
                      ),
                      const SizedBox(height: 16),

                      // Cuándo usar switch
                      Card(
                        elevation: 4,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        color: AppColors.successGradient.colors.first.withOpacity(0.2),
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                _contentData!['subtema2']['cuando_usar_switch']['titulo'],
                                style: GoogleFonts.poppins(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600,
                                  color: AppColors.textPrimary,
                                ),
                              ),
                              const SizedBox(height: 12),
                              _buildBulletList(_contentData!['subtema2']['cuando_usar_switch']['items']),
                              const SizedBox(height: 12),
                              Text(
                                _contentData!['subtema2']['cuando_usar_switch']['conclusion'],
                                style: GoogleFonts.poppins(
                                  fontSize: 15,
                                  color: AppColors.textSecondary,
                                  fontStyle: FontStyle.italic,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 24),
                    ],
                  ),

                // Subtema 3: Bucles
                if (_contentData?['subtema3'] != null)
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _contentData!['subtema3']['titulo'],
                        style: GoogleFonts.poppins(
                          fontSize: 22,
                          fontWeight: FontWeight.w600,
                          color: AppColors.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 12),
                      ..._formatContent(_contentData!['subtema3']['contenido']),
                      const SizedBox(height: 16),

                      // Lista de bucles
                      ..._contentData!['subtema3']['bucles'].map<Widget>((bucle) {
                        Color color;
                        switch (bucle['color']) {
                          case 'orange':
                            color = AppColors.warning;
                            break;
                          case 'purple':
                            color = Colors.purple;
                            break;
                          case 'indigo':
                            color = Colors.indigo;
                            break;
                          default:
                            color = AppColors.warning;
                        }

                        return Card(
                          elevation: 4,
                          margin: const EdgeInsets.only(bottom: 24),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          color: color.withOpacity(0.2),
                          child: Padding(
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Bucle ${bucle['tipo']}",
                                  style: GoogleFonts.poppins(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w600,
                                    color: AppColors.textPrimary,
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  bucle['descripcion'],
                                  style: GoogleFonts.poppins(
                                    fontSize: 15,
                                    color: AppColors.textSecondary,
                                  ),
                                ),
                                const SizedBox(height: 12),
                                Text(
                                  "¿Qué es?",
                                  style: GoogleFonts.poppins(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600,
                                    color: AppColors.textPrimary,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  bucle['definicion'],
                                  style: GoogleFonts.poppins(
                                    fontSize: 15,
                                    color: AppColors.textSecondary,
                                    fontStyle: FontStyle.italic,
                                  ),
                                ),
                                const SizedBox(height: 12),
                                Text(
                                  bucle['explicacion'],
                                  style: GoogleFonts.poppins(
                                    fontSize: 15,
                                    color: AppColors.textSecondary,
                                  ),
                                ),
                                const SizedBox(height: 12),
                                Text(
                                  "Estructura",
                                  style: GoogleFonts.poppins(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600,
                                    color: AppColors.textPrimary,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  bucle['estructura'],
                                  style: GoogleFonts.poppins(
                                    fontSize: 15,
                                    color: AppColors.textSecondary,
                                  ),
                                ),
                                const SizedBox(height: 12),

                                // Ejemplos de código
                                Column(
                                  children: bucle['ejemplos'].map<Widget>((ejemplo) {
                                    return Padding(
                                      padding: const EdgeInsets.only(bottom: 12),
                                      child: _buildCodeBox(
                                        ejemplo['codigo'],
                                        ejemplo['lenguaje'],
                                      ),
                                    );
                                  }).toList(),
                                ),

                                const SizedBox(height: 12),
                                Text(
                                  "¿Cuándo utilizarlo?",
                                  style: GoogleFonts.poppins(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600,
                                    color: AppColors.textPrimary,
                                  ),
                                ),
                                const SizedBox(height: 8),
                                _buildBulletList(bucle['cuando_usar']),
                                const SizedBox(height: 12),
                                Text(
                                  bucle['conclusion'],
                                  style: GoogleFonts.poppins(
                                    fontSize: 15,
                                    color: AppColors.textSecondary,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      }).toList(),

                      // Nota importante final
                      _buildHighlightBox(
                        _contentData!['subtema3']['nota_importante']['text'],
                        color: AppColors.successGradient.colors.first.withOpacity(0.2),
                        title: "Importante",
                      ),
                      const SizedBox(height: 24),
                    ],
                  ),

                // Quiz Section
                _buildQuizSection(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}